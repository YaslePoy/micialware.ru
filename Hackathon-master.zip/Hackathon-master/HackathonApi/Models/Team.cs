namespace HackathonApi.Models;

public class Team : DbNamed
{
    public string Description { get; set; }
}