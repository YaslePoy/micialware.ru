namespace HackathonApi.DTO;

public class SolutionDTO
{
    public string Text { get; set; }
    public int TaskId { get; set; }
    public int TeamId { get; set; }
}